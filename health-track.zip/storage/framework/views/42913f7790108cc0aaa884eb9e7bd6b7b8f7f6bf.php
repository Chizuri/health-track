<?php $__env->startSection('content'); ?>

    <script>
        $(document).ready(function() {
            var f = new Date();
            var d = f.getDate();
            if(d < 10) { d = '0'+d; }
            var today = f.getFullYear() + '-' + (f.getMonth() +1) + '-' + d;

            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    //right: 'month,basicWeek,basicDay,listWeek'
                    right: 'month,agendaWeek,agendaDay,listWeek'
                },
                defaultDate: today,
                navLinks: true, // can click day/week names to navigate views
                editable: true,
                eventLimit: true, // allow 'more' link when too many events
                events: [
                    <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cit): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    {
                        id: '<?php echo e($cit->id); ?>'
                        ,title: '<?php echo e($cit->paciente); ?>'
                        ,url: '<?php echo e(url('/citas/'.$cit->id)); ?>'
                        ,start: '<?php echo e($cit->fecha); ?>T<?php echo e($cit->hora); ?>'
                        <?php if($cit->estado == 'T'): ?>
                        ,constraint: 'availableForMeeting' // defined below
                        ,color: '#257e4a'
                        <?php endif; ?>
                    },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    /*events: [
                     {
                     title: 'Click for Google',
                     url: 'http://google.com/',
                     start: '2016-09-28'
                     },
                     ]*/
                ],
                dayClick: function() {
                    alert('a day has been clicked!');
                }
            });
        });
    </script>

    <div class="row">
            <div id="calendar"></div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>